class Custom extends Error{
    constructor(message){
        super(message)
    }
}
module.exports=Custom